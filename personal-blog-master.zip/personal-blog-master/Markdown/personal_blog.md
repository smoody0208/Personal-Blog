# Personal Blog

##### Hello, I'm pendleton and this is my blog. I'm going to list out a few things here and make use of formatting.

### Vacation Spots
* Miami
* The mountains (any mountains)
* Hawaii

### Favorite Foods
1.  pizza
2. captain crunch
3. is there more food?

### Hobbies
1. Snowboarding
2. Reading
3. Hiking
4. Piano
5. Welding